import { useState, useMemo, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  format,
  startOfYear,
  endOfYear,
  eachDayOfInterval,
  eachWeekOfInterval,
  startOfWeek,
  endOfWeek,
  startOfMonth,
  endOfMonth,
  getMonth,
  getYear,
  getDay,
  isToday,
  parseISO,
  isSameMonth,
  getWeek,
} from 'date-fns';
import { ChevronLeft, ChevronRight, Edit, X } from 'lucide-react';
import type { JournalEntry, Era } from '@/app/types';
import { Button } from '@/app/components/ui/button';
import { erasStorage } from '@/app/utils/eras';
import { getSmartPrompt } from '@/app/utils/prompts';
import { getGitaDailyPrompt } from '@/app/utils/prompts-v2';

type ReflectionEntryType = 'weekly' | 'monthly' | 'yearly';

interface TimelineViewProps {
  entries: JournalEntry[];
  onSelectDate: (date: string) => void;
  onEditEntry: (date: string) => void;
  onReflectionEntry: (date: string, type: ReflectionEntryType) => void;
  activeIntention?: { text: string; type: 'weekly' | 'monthly' };
}

// ── Mood colour system ─────────────────────────────────────────────────────
// Decision 3 (agreed): faint dot colours deepened so they're visible on parchment.
// okay: slate-300 → slate-400 (was ghostly), difficult: slate-400 → slate-500
// Decision 3 (agreed): faint dot colours deepened so they're visible on parchment.
const MOOD_CELL: Record<string, string> = {
  great:     'bg-amber-400',
  good:      'bg-stone-400',
  okay:      'bg-stone-300',
  low:       'bg-stone-400',
  difficult: 'bg-stone-500',
};
// Inline styles for mood cells that need exact warm palette colors
const MOOD_CELL_STYLE: Record<string, string> = {
  great:     '#B8663F', // Accent color
  good:      '#8C9A8E', // Muted Sage
  okay:      '#8A96A3', // Muted Blue
  low:       '#B0A8A0', // Warm Stone
  difficult: '#7D7670', // Deep Stone
};
const MOOD_LABEL: Record<string, string> = {
  great: 'Vibrant', good: 'Peaceful', okay: 'Balanced', low: 'Heavy', difficult: 'Hard',
};
const MOOD_ORDER: string[] = ['low', 'okay', 'good', 'great', 'difficult'];
const MOOD_EMOJI: Record<string, string> = {
  great: '✨', good: '🌿', okay: '○', low: '◌', difficult: '·',
};

const MOOD_BG: Record<string, string> = {
  great:     'bg-amber-50 border-amber-200',
  good:      'bg-stone-50 border-stone-200',
  okay:      'bg-stone-50 border-stone-200',
  low:       'bg-stone-100 border-stone-200',
  difficult: 'bg-stone-100 border-stone-300',
};
const MOOD_TEXT: Record<string, string> = {
  great: 'text-amber-700', good: 'text-stone-600', okay: 'text-stone-500',
  low: 'text-stone-500', difficult: 'text-stone-600',
};

type DrillLevel = 'year' | 'month' | 'week' | 'day';

const MONTH_NAMES = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
const DAY_LABELS  = ['S','M','T','W','T','F','S'];

// ── Helpers ────────────────────────────────────────────────────────────────
function buildEntryMap(entries: JournalEntry[]): Map<string, JournalEntry> {
  const map = new Map<string, JournalEntry>();
  entries.forEach(e => map.set(e.date, e));
  return map;
}

/** Returns the reflection entry for a given period, if one exists */
function findReflectionEntry(
  entries: JournalEntry[],
  type: ReflectionEntryType,
  periodKey: string   // 'YYYY-MM' for monthly, 'YYYY-MM-DD' (week start) for weekly, 'YYYY' for yearly
): JournalEntry | undefined {
  return entries.find(e => {
    if (e.reflectionType !== type) return false;
    if (type === 'monthly') return e.date === `reflection-monthly-${periodKey}`;
    if (type === 'yearly')  return e.date === `reflection-yearly-${periodKey}`;
    if (type === 'weekly')  return e.date === `reflection-weekly-${periodKey}`;
    return false;
  });
}

/** Small badge shown on month label / week number when a reflection entry exists */
function ReflectionDot({ type }: { type: ReflectionEntryType }) {
  const colours: Record<ReflectionEntryType, string> = {
    weekly:  'bg-amber-500',
    monthly: 'bg-stone-400',
    yearly:  'bg-amber-400',
  };
  return (
    <span
      className={`inline-block w-1.5 h-1.5 rounded-full ml-1 ${colours[type]} shrink-0 align-middle`}
      title={`${type} reflection written`}
    />
  );
}

function dominantMood(entries: JournalEntry[]): string | null {
  const counts: Record<string, number> = {};
  entries.forEach(e => { if (e.mood) counts[e.mood] = (counts[e.mood] || 0) + 1; });
  const sorted = Object.entries(counts).sort((a, b) => b[1] - a[1]);
  return sorted[0]?.[0] ?? null;
}

function summaryLine(entries: JournalEntry[]): string {
  const dailyEntries = entries.filter(e => !e.date.startsWith('reflection-'));
  const total = dailyEntries.length;
  if (total === 0) return '';
  const mood = dominantMood(dailyEntries);
  // Witness-compliant: never surface negative tallies, tender language for hard periods
  const MOOD_PHRASE: Record<string, string> = {
    great:     'A mostly great year so far',
    good:      'A mostly good year so far',
    okay:      'A steady year so far',
    low:       'A tender year so far',
    difficult: 'A tender year so far',
  };
  const moodStr = mood ? ` · ${MOOD_PHRASE[mood]}` : '';
  return `${total} ${total === 1 ? 'entry' : 'entries'}${moodStr}`;
}

/** Returns the day-of-week name the user writes most often - a pure witness observation */
function mostActiveDay(entries: JournalEntry[]): string | null {
  const daily = entries.filter(e => !e.date.startsWith('reflection-'));
  if (daily.length < 4) return null; // not enough data to be meaningful
  const counts: Record<number, number> = {};
  daily.forEach(e => {
    try {
      const dow = getDay(parseISO(e.date)); // 0 = Sun
      counts[dow] = (counts[dow] || 0) + 1;
    } catch { /* skip malformed dates */ }
  });
  const sorted = Object.entries(counts).sort((a, b) => b[1] - a[1]);
  if (!sorted[0]) return null;
  const DAY_NAMES = ['Sundays', 'Mondays', 'Tuesdays', 'Wednesdays', 'Thursdays', 'Fridays', 'Saturdays'];
  return DAY_NAMES[Number(sorted[0][0])];
}
export function TimelineView({ entries, onSelectDate, onEditEntry, onReflectionEntry, activeIntention }: TimelineViewProps) {
  const [year, setYear]         = useState(getYear(new Date()));
  const [level, setLevel]       = useState<DrillLevel>('year');
  const [focusMonth, setFocus]  = useState<number>(getMonth(new Date())); // 0-indexed
  const [focusWeek, setFocusW]  = useState<Date>(startOfWeek(new Date()));
  const [focusDay, setFocusDay] = useState<string | null>(null);
  const [activeTagFilter, setActiveTagFilter] = useState<string | null>(null);
  const [activeEraFilter, setActiveEraFilter] = useState<string | null>(null);
  const [eras, setEras] = useState<Era[]>([]);

  const handlePrevYear = () => setYear(y => y - 1);
  const handleNextYear = () => setYear(y => y + 1);
  const handleWriteToday = () => onSelectDate(format(new Date(), 'yyyy-MM-dd'));


  useEffect(() => {
    setEras(erasStorage.getAll());
  }, []);

  const activeErasThisYear = useMemo(() => {
    const ys = startOfYear(new Date(year, 0, 1)).getTime();
    const ye = endOfYear(new Date(year, 0, 1)).getTime();
    return eras.filter(era => {
      if (!era.startDate) return false;
      const st = parseISO(era.startDate).getTime();
      const en = era.endDate ? parseISO(era.endDate).getTime() : Infinity;
      return st <= ye && en >= ys;
    });
  }, [eras, year]);

  // ── First-run empty state ──────────────────────────────────────────────
  const dailyEntries = useMemo(() => entries.filter(e => !e.date.startsWith('reflection-')), [entries]);
  const hasEntries = dailyEntries.length > 0;
  const [welcomeDismissed, setWelcomeDismissed] = useState(
    () => localStorage.getItem('journal_first_visit_dismissed') === 'true'
  );
  const showWelcome = !hasEntries && !welcomeDismissed;

  const handleDismissWelcome = () => {
    localStorage.setItem('journal_first_visit_dismissed', 'true');
    setWelcomeDismissed(true);
  };

  // ── Daily opening prompt ───────────────────────────────────────────────
  const [showDailyPrompt, setShowDailyPrompt] = useState(() => {
    const today = format(new Date(), 'yyyy-MM-dd');
    const lastShown = localStorage.getItem('last_prompt_shown_date');
    if (lastShown !== today) {
      localStorage.setItem('last_prompt_shown_date', today);
      return true;
    }
    return false;
  });
  // Combined daily prompt pool - existing smart prompts + Gita-informed prompts (A8a)
  // 50/50 split gives both pools equal rotation weight without changing the once-per-day gate
  const [dailyPrompt] = useState(() =>
    Math.random() < 0.5 ? getSmartPrompt(entries) : getGitaDailyPrompt()
  );

  useEffect(() => {
    if (!showDailyPrompt) return;
    const timer = setTimeout(() => setShowDailyPrompt(false), 6000);
    return () => clearTimeout(timer);
  }, [showDailyPrompt]);

  const entryMap = useMemo(() => buildEntryMap(entries), [entries]);

  const yearEntries = useMemo(() =>
    entries.filter(e => getYear(parseISO(e.date)) === year),
    [entries, year]
  );

  // ── Active Era per Drill-down Context ──────────────────────────────────
  const activeFocusDay = useMemo(() => {
    if (level === 'day' && focusDay) return parseISO(focusDay);
    if (level === 'week') return focusWeek;
    if (level === 'month') return new Date(year, focusMonth, 1);
    return null;
  }, [level, focusDay, focusWeek, year, focusMonth]);

  const activeFocusEra = useMemo(() => {
    if (!activeFocusDay) return null;
    const t = activeFocusDay.getTime();
    return eras.find(era => {
      if (!era.startDate) return false;
      const st = parseISO(era.startDate).getTime();
      const en = era.endDate ? parseISO(era.endDate).getTime() : Infinity;
      return t >= st && t <= en;
    });
  }, [activeFocusDay, eras]);

  // ── SUB-COMPONENTS ──────────────────────────────────────────────────────
  


  const DailyHeatmap = () => {
    // Heatmap cell coloring based on mood (Witness refined A11c)
    const getCellColor = (entry: any) => {
      if (!entry || !entry.mood) return null;
      return MOOD_CELL_STYLE[entry.mood] || null;
    };

    return (
      <div className="flex-1 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 px-2 min-h-0">
        {MONTH_NAMES.map((name, mi) => {
          const mStart = startOfMonth(new Date(year, mi, 1));
          const mEnd   = endOfMonth(mStart);
          const monthDays = eachDayOfInterval({ start: mStart, end: mEnd });
          const paddingBefore = getDay(monthDays[0]);

          return (
            <motion.div
              key={name}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: mi * 0.05 }}
              className="rounded-[16px] border border-[#EAE6DF] p-5 flex flex-col min-h-0 cursor-pointer group hover:border-[#B8663F] transition-colors"
              style={{ 
                backgroundColor: '#F8F6F2',
                boxShadow: '0 4px 20px rgba(0,0,0,0.03), 0 2px 4px rgba(0,0,0,0.02)' 
              }}
              onClick={() => { setFocus(mi); setLevel('month'); }}
            >
              <div className="flex items-center justify-between mb-3 px-1">
                <h3 className="text-lg font-semibold text-[#2E2A26] mx-auto group-hover:text-[#B8663F] transition-colors" style={{ fontFamily: '"Source Serif Pro", serif' }}>{name}</h3>
              </div>

              <div className="flex flex-col items-center justify-center flex-1 min-h-0">
                <div className="w-full max-w-[200px]">
                  <div className="grid grid-cols-7 gap-1.5 mb-1.5 opacity-40 justify-items-center">
                    {DAY_LABELS.map((d, i) => (
                      <div key={i} className="text-[10px] text-[#6F6860] font-normal text-center w-full">{d}</div>
                    ))}
                  </div>

                  <div className="grid grid-cols-7 gap-1.5 items-start content-start justify-items-center">
                    {Array(paddingBefore).fill(null).map((_, i) => (
                      <div key={`pad-${i}`} className="aspect-square w-full" />
                    ))}
                    {monthDays.map(day => {
                      const ds    = format(day, 'yyyy-MM-dd');
                      const entry = entryMap.get(ds);
                      const todayC = isToday(day);
                      const cellColor = getCellColor(entry);
                      
                      const currentEras = eras.filter(era => {
                        if (!era.startDate) return false;
                        const st = new Date(era.startDate).getTime();
                        const en = era.endDate ? new Date(era.endDate).getTime() : Infinity;
                        const t = day.getTime();
                        return t >= st && t <= en;
                      });
                      const activeEra = currentEras[0];

                      return (
                        <motion.button
                          key={ds}
                          whileHover={{ scale: 1.05 }}
                          whileTap={{ scale: 0.98 }}
                          title={format(day, 'MMMM d, yyyy')}
                          onClick={(e) => {
                            e.stopPropagation();
                            if (entry) { setFocus(mi); setFocusDay(ds); setLevel('day'); }
                            else onSelectDate(ds);
                          }}
                          className="aspect-square w-full relative flex items-center justify-center transition-opacity"
                        >
                          <div
                            className={`w-full h-full rounded-[3px] transition-all 
                              ${!cellColor 
                                ? activeEra
                                  ? 'bg-[#E6DFD6] opacity-60'
                                  : 'bg-[#E6DFD6] hover:bg-[#DED6CC]' 
                                : ''
                              }
                              ${todayC ? 'ring-[1.5px] ring-[#B8663F] ring-offset-1 ring-offset-[#F1ECE5]' : ''}
                            `}
                            style={cellColor ? { backgroundColor: cellColor } : undefined}
                          />
                          {todayC && <span className="absolute inset-0 flex items-center justify-center text-[8px] font-bold text-[#B8663F] pointer-events-none">{format(day, 'd')}</span>}
                        </motion.button>
                      );
                    })}
                  </div>
                </div>
              </div>
            </motion.div>
          );
        })}
      </div>
    );
  };

  const LegendFooter = () => {
    const currentYearEra = eras.find(era => {
      const today = new Date().getTime();
      const st = new Date(era.startDate || '').getTime();
      const en = era.endDate ? new Date(era.endDate).getTime() : Infinity;
      return today >= st && today <= en;
    });

    return (
      <div className="mt-8 flex items-center justify-between px-6 max-w-[1200px] mx-auto w-full opacity-60 shrink-0">
        <div className="flex items-center gap-4">
          <span className="text-[10px] font-semibold uppercase tracking-widest text-[#6F6860]">Less</span>
          <div className="flex gap-1.5">
            <div className="w-[12px] h-[12px] rounded-[2px] bg-[#E6DFD6]" title="No entry" />
            <div className="w-[12px] h-[12px] rounded-[2px] bg-[#4B5563]" title="Low activity" />
            <div className="w-[12px] h-[12px] rounded-[2px] bg-[#0D9488]" title="Medium activity" />
            <div className="w-[12px] h-[12px] rounded-[2px] bg-[#D97706]" title="High activity" />
          </div>
          <span className="text-[10px] font-semibold uppercase tracking-widest text-[#6F6860]">More</span>
        </div>
        {currentYearEra && (
          <div className="flex items-center gap-2">
            <span className="text-[10px] font-semibold uppercase tracking-widest text-[#6F6860]">Chapters:</span>
            <span className="text-[10px] font-bold uppercase tracking-widest text-[#B8663F]">{currentYearEra.name}</span>
          </div>
        )}
      </div>
    );
  };

  const BelowHeatmap = () => {
    const activeDayStr = mostActiveDay(entries.filter(e => e.date && !e.reflectionType && getYear(parseISO(e.date)) === year));
    return (
      <div className="mt-2 space-y-1 text-center max-w-md mx-auto">
        <AnimatePresence>
          {showDailyPrompt && (
            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 0.7 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 1.2 }}
              className="text-stone-400 text-[12px] italic leading-relaxed cursor-pointer"
              onClick={() => setShowDailyPrompt(false)}
              style={{ fontFamily: 'ui-serif, Georgia, serif' }}
            >
              {dailyPrompt}
            </motion.p>
          )}
        </AnimatePresence>
        {activeDayStr && <p className="text-[9px] text-stone-400 font-medium uppercase tracking-widest">Mostly writing on {activeDayStr}</p>}
        {activeIntention && activeIntention.text.trim().length >= 3 && (
          <div className="pt-0.5">
            <p className="text-[9px] text-stone-400 font-medium uppercase tracking-widest">
              {activeIntention.type === 'monthly' ? 'Monthly' : 'Weekly'} Intent: "{activeIntention.text}"
            </p>
          </div>
        )}
      </div>
    );
  };

  const FilterStrip = () => {
    if (!activeTagFilter && !activeEraFilter) return null;
    const activeEra = activeEraFilter ? eras.find(e => e.id === activeEraFilter) : null;
    return (
      <motion.div initial={{ opacity: 0, y: -4 }} animate={{ opacity: 1, y: 0 }} className="flex justify-center items-center gap-3 mb-4">
        <span className="text-[10px] font-medium uppercase tracking-widest" style={{ color: '#6F6860' }}>Filtered</span>
        {activeTagFilter && (
          <span className="inline-flex items-center gap-1.5 px-2 py-0.5 bg-[#2E2A26] text-[#F5F3EF] text-[10px] rounded-full font-medium">
            {activeTagFilter} <button onClick={() => setActiveTagFilter(null)} className="opacity-60 hover:opacity-100">×</button>
          </span>
        )}
        {activeEra && (
          <span className="inline-flex items-center gap-1.5 px-2 py-0.5 border border-[#E2DBD2] text-[10px] rounded-full font-medium" style={{ backgroundColor: (activeEra.colour || '#B8663F') + '15', color: '#2E2A26' }}>
            {activeEra.name} <button onClick={() => setActiveEraFilter(null)} className="opacity-60 hover:opacity-100">×</button>
          </span>
        )}
        <button onClick={() => { setActiveTagFilter(null); setActiveEraFilter(null); }} className="text-[10px] underline hover:opacity-100 opacity-60" style={{ color: '#6F6860' }}>clear</button>
      </motion.div>
    );
  };

  // ── REFLECTION PANEL - replaces flat banners in Month/Week/Year views ─
  const REFLECTION_PANEL_META: Record<ReflectionEntryType, {
    label: string;
    emptyLabel: string;
    emptyPrompt: string;
    accentText: string;
    accentButton: string;
    dotCls: string;
  }> = {
    weekly: {
      label:        'Weekly reflection',
      emptyLabel:   'No weekly reflection yet',
      emptyPrompt:  'How did the week unfold? What mattered most?',
      accentText:   'text-amber-700',
      accentButton: 'text-stone-500 hover:text-stone-700 border-stone-200 hover:border-stone-400',
      dotCls:       'bg-amber-500',
    },
    monthly: {
      label:        'Monthly reflection',
      emptyLabel:   'No monthly reflection yet',
      emptyPrompt:  'What defined this month? What shifted?',
      accentText:   'text-stone-600',
      accentButton: 'text-stone-500 hover:text-stone-700 border-stone-200 hover:border-stone-400',
      dotCls:       'bg-stone-400',
    },
    yearly: {
      label:        'Yearly reflection',
      emptyLabel:   'No yearly reflection yet',
      emptyPrompt:  'What chapters defined this year? Who did you become?',
      accentText:   'text-amber-600',
      accentButton: 'text-stone-500 hover:text-stone-700 border-stone-200 hover:border-stone-400',
      dotCls:       'bg-amber-400',
    },
  };

  const ReflectionPanel = ({
    type,
    reflection,
    onWrite,
    onEdit,
  }: {
    type: ReflectionEntryType;
    reflection: JournalEntry | undefined;
    onWrite: () => void;
    onEdit: () => void;
  }) => {
    const meta = REFLECTION_PANEL_META[type];

    const FIELD_LABELS: Record<string, string> = {
      whatHappened: type === 'weekly'  ? 'This week'
                  : type === 'monthly' ? 'This month'
                  : 'This year',
      feelings:     'How it felt',
      whatMatters:  'What mattered most',
      insight:      'What I learned',
      freeWrite:    type === 'weekly'  ? 'Carrying forward'
                  : type === 'monthly' ? 'Carrying forward'
                  : 'Leaving behind',
    };

    if (!reflection) {
      return (
        <motion.div
          initial={{ opacity: 0, y: -4 }}
          animate={{ opacity: 1, y: 0 }}
          className="rounded-2xl px-5 py-4 mb-5"
          style={{
            backgroundColor: 'var(--card)',
            border: '1.5px solid rgba(28,28,24,0.22)',
            boxShadow: '0 2px 8px rgba(28,28,24,0.10)',
          }}
        >
          <div className="flex items-center justify-between">
            <div>
              <p className={`text-xs font-semibold uppercase tracking-wide mb-0.5 ${meta.accentText}`}>
                {meta.emptyLabel}
              </p>
              <p className="text-sm text-stone-400 italic">{meta.emptyPrompt}</p>
            </div>
            <button
              onClick={onWrite}
              className={`ml-4 shrink-0 text-xs px-3 py-1.5 rounded-lg border transition-colors ${meta.accentButton}`}
            >
              Write →
            </button>
          </div>
        </motion.div>
      );
    }

    // Written state - show full content
    const fields: { key: keyof JournalEntry; label: string }[] = [
      { key: 'whatHappened', label: FIELD_LABELS.whatHappened },
      { key: 'feelings',     label: FIELD_LABELS.feelings },
      { key: 'whatMatters',  label: FIELD_LABELS.whatMatters },
      { key: 'insight',      label: FIELD_LABELS.insight },
      { key: 'freeWrite',    label: FIELD_LABELS.freeWrite },
    ];

    return (
      <motion.div
        initial={{ opacity: 0, y: -4 }}
        animate={{ opacity: 1, y: 0 }}
        className="rounded-2xl px-5 py-4 mb-5"
        style={{
          backgroundColor: 'var(--card)',
          border: '1.5px solid rgba(28,28,24,0.22)',
          boxShadow: '0 2px 8px rgba(28,28,24,0.10)',
        }}
      >
        {/* Header row */}
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <span className={`w-2 h-2 rounded-full shrink-0 ${meta.dotCls}`} />
            <p className={`text-xs font-semibold uppercase tracking-wide ${meta.accentText}`}>
              {meta.label}
            </p>
            {reflection.mood && (
              <span className="text-base leading-none ml-1">{MOOD_EMOJI[reflection.mood]}</span>
            )}
          </div>
          <button
            onClick={onEdit}
            className={`flex items-center gap-1.5 text-xs px-2.5 py-1 rounded-lg border transition-colors ${meta.accentButton}`}
          >
            <Edit className="size-3" />
            Edit
          </button>
        </div>

        {/* Intention - prominent at top, shown before content */}
        {(reflection as JournalEntry & { intention?: string }).intention && (
          <div className="mb-4 pb-3 border-b border-stone-200/60">
            <p className="text-[10px] text-stone-400 uppercase tracking-wide mb-1">Intention</p>
            <p className={`text-sm italic font-medium ${meta.accentText} leading-relaxed`}>
              "{(reflection as JournalEntry & { intention?: string }).intention}"
            </p>
          </div>
        )}

        {/* Content fields - below intention */}
        <div className="space-y-3">
          {fields.map(({ key, label }) => {
            const val = reflection[key] as string | undefined;
            if (!val) return null;
            return (
              <div key={String(key)}>
                <p className="text-[10px] text-stone-400 uppercase tracking-wide mb-0.5">{label}</p>
                <p className="text-sm text-stone-600 leading-relaxed whitespace-pre-wrap line-clamp-4">
                  {val}
                </p>
              </div>
            );
          })}
        </div>
      </motion.div>
    );
  };

  // ── MONTH VIEW ─────────────────────────────────────────────────────────
  const MonthView = () => {
    const mStart = startOfMonth(new Date(year, focusMonth, 1));
    const mEnd   = endOfMonth(mStart);
    const weeks  = eachWeekOfInterval({ start: mStart, end: mEnd });
    const periodKey = format(mStart, 'yyyy-MM');
    const monthlyReflection = findReflectionEntry(entries, 'monthly', periodKey);

    // Scroll-triggered swap - calendar fades out when reflection sentinel enters viewport
    const sentinelRef = useRef<HTMLDivElement>(null);
    const [reflectionVisible, setReflectionVisible] = useState(false);

    useEffect(() => {
      const el = sentinelRef.current;
      if (!el) return;
      const observer = new IntersectionObserver(
        ([entry]) => setReflectionVisible(entry.isIntersecting),
        { threshold: 0.15 }
      );
      observer.observe(el);
      return () => observer.disconnect();
    }, []);

    const monthlyKey = `reflection-monthly-${year}-${String(focusMonth + 1).padStart(2, '0')}`;

    return (
      <div className="space-y-3">
        {/* Calendar - fades out when reflection scrolls into view */}
        <motion.div
          animate={{ opacity: reflectionVisible ? 0.15 : 1 }}
          transition={{ duration: 0.5 }}
        >
          {/* Day headers */}
          <div className="grid grid-cols-7 gap-2 mb-1">
            {['Sun','Mon','Tue','Wed','Thu','Fri','Sat'].map(d => (
              <div key={d} className="text-xs text-center text-stone-400 font-medium">{d}</div>
            ))}
          </div>

          {weeks.map((weekStart, wi) => {
            const weekEnd    = endOfWeek(weekStart);
            const weekDays   = eachDayOfInterval({ start: weekStart, end: weekEnd });
            const weekEntries = weekDays
              .map(d => entryMap.get(format(d, 'yyyy-MM-dd')))
              .filter(Boolean) as JournalEntry[];
            void weekEntries;

            return (
              <div key={wi} className="relative mb-3">
                {/* Week row header - click → drill into week */}
                {(() => {
                  const weekKey = format(weekStart, 'yyyy-MM-dd');
                  const hasWeeklyReflection = entries.some(
                    e => e.reflectionType === 'weekly' && e.date === `reflection-weekly-${weekKey}`
                  );
                  return (
                    <button
                      onClick={() => { setFocusW(weekStart); setLevel('week'); }}
                      className="absolute -left-6 top-1/2 -translate-y-1/2 flex items-center gap-0.5 text-[10px] text-stone-400 hover:text-stone-500 transition-colors"
                      title="View this week"
                    >
                      W{getWeek(weekStart)}
                      {hasWeeklyReflection && <ReflectionDot type="weekly" />}
                    </button>
                  );
                })()}

                <div className="grid grid-cols-7 gap-2">
                  {weekDays.map(day => {
                    const ds       = format(day, 'yyyy-MM-dd');
                    const entry    = entryMap.get(ds);
                    const inMonth  = isSameMonth(day, mStart);
                    const todayC   = isToday(day);
                    const tagMatch = !activeTagFilter || (entry?.tags?.includes(activeTagFilter) ?? false);

                    return (
                      <motion.button
                        key={ds}
                        whileHover={{ scale: 1.03 }}
                        whileTap={{ scale: 0.97 }}
                        onClick={() => {
                          setFocusW(weekStart);
                          if (entry) { setFocusDay(ds); setLevel('day'); }
                          else onSelectDate(ds);
                        }}
                        className={`
                          aspect-square rounded-lg transition-all flex flex-col items-center justify-center
                          text-sm relative
                          ${!inMonth ? 'opacity-20' : ''}
                          ${entry?.mood
                            ? 'text-stone-800 font-medium'
                            : entry
                              ? 'text-stone-600'
                              : 'text-stone-400 hover:text-stone-500'
                          }
                          ${todayC ? 'ring-2 ring-amber-500 ring-offset-1' : ''}
                          ${activeTagFilter && !tagMatch && inMonth ? 'opacity-20' : ''}
                        `}
                        style={
                          entry?.mood
                            ? {
                                backgroundColor: MOOD_CELL_STYLE[entry.mood] + 'AA',
                                border: '1.5px solid rgba(28,28,24,0.18)',
                                boxShadow: '0 1px 4px rgba(28,28,24,0.10)',
                              }
                            : entry
                              ? {
                                  backgroundColor: 'var(--card)',
                                  border: '1.5px solid rgba(28,28,24,0.20)',
                                  boxShadow: '0 1px 4px rgba(28,28,24,0.10)',
                                }
                              : {
                                  backgroundColor: 'var(--card)',
                                  border: '1px solid rgba(28,28,24,0.12)',
                                  opacity: 0.5,
                                }
                        }
                      >
                        <span>{format(day, 'd')}</span>
                        {entry?.mood && (
                          <span className="text-[10px] leading-none mt-0.5 opacity-80">{MOOD_EMOJI[entry.mood]}</span>
                        )}
                      </motion.button>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </motion.div>

        {/* Sentinel - reflection panel fades in as it enters viewport */}
        <div ref={sentinelRef} className="mt-6">
          <motion.div
            animate={{ opacity: reflectionVisible ? 1 : 0, y: reflectionVisible ? 0 : 12 }}
            transition={{ duration: 0.5 }}
          >
            <ReflectionPanel
              type="monthly"
              reflection={monthlyReflection}
              onWrite={() => onReflectionEntry(monthlyKey, 'monthly')}
              onEdit={() => onEditEntry(monthlyReflection!.date)}
            />
          </motion.div>
        </div>
      </div>
    );
  };

  // ── WEEK VIEW - vertical timeline dots ────────────────────────────────
  const WeekView = () => {
    const wEnd   = endOfWeek(focusWeek);
    const wDays  = eachDayOfInterval({ start: focusWeek, end: wEnd });
    const weekKey = format(focusWeek, 'yyyy-MM-dd');
    const weeklyReflection = findReflectionEntry(entries, 'weekly', weekKey);

    // Scroll-triggered swap - timeline fades out when reflection sentinel enters viewport
    const sentinelRef = useRef<HTMLDivElement>(null);
    const [reflectionVisible, setReflectionVisible] = useState(false);

    useEffect(() => {
      const el = sentinelRef.current;
      if (!el) return;
      const observer = new IntersectionObserver(
        ([entry]) => setReflectionVisible(entry.isIntersecting),
        { threshold: 0.15 }
      );
      observer.observe(el);
      return () => observer.disconnect();
    }, []);

    const weeklyKey = `reflection-weekly-${format(focusWeek, 'yyyy-MM-dd')}`;

    return (
      <div className="max-w-lg">
        {/* Timeline - fades out when reflection scrolls into view */}
        <motion.div
          className="relative"
          animate={{ opacity: reflectionVisible ? 0.15 : 1 }}
          transition={{ duration: 0.5 }}
        >
          {/* Vertical line */}
          <div className="absolute left-[22px] top-4 bottom-4 w-px bg-stone-200" />

          <div className="space-y-4">
            {wDays.map((day, i) => {
              const ds    = format(day, 'yyyy-MM-dd');
              const entry = entryMap.get(ds);
              const today = isToday(day);
              const dotCls = entry?.mood ? '' : today ? 'bg-stone-400' : 'bg-stone-200';
              const dotStyle = entry?.mood ? { backgroundColor: MOOD_CELL_STYLE[entry.mood] } : undefined;
              const tagMatch = !activeTagFilter || (entry?.tags?.includes(activeTagFilter) ?? false);

              return (
                <motion.div
                  key={ds}
                  className={`flex items-start gap-4 transition-opacity ${activeTagFilter && !tagMatch ? 'opacity-25' : ''}`}
                >
                  {/* Dot */}
                  <button
                    onClick={() => {
                      if (entry) { setFocusDay(ds); setLevel('day'); }
                      else onSelectDate(ds);
                    }}
                    className={`
                      w-[10px] h-[10px] rounded-full mt-3 shrink-0 relative z-10 transition-all
                      ${dotCls} ${entry ? 'scale-125 hover:scale-150' : 'hover:bg-stone-300'}
                      ${today ? 'ring-2 ring-stone-500 ring-offset-1' : ''}
                    `}
                    style={dotStyle}
                    title={ds}
                  />

                  {/* Day content */}
                  <div
                    className="flex-1 rounded-xl p-3 transition-all"
                    style={{
                      backgroundColor: 'var(--card)',
                      border: entry
                        ? '1px solid rgba(28,28,24,0.18)'
                        : '1px solid rgba(28,28,24,0.10)',
                      boxShadow: entry ? '0 1px 4px rgba(28,28,24,0.08)' : undefined,
                      opacity: entry ? 1 : 0.6,
                    }}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className={`text-sm font-medium ${today ? '' : 'text-stone-500'}`}
                        style={today ? { color: '#3C3C38' } : undefined}>
                        {format(day, 'EEEE')}
                        <span className="font-normal text-stone-400 ml-1.5">{format(day, 'MMM d')}</span>
                      </span>
                      {entry?.mood && (
                        <span className="text-base">{MOOD_EMOJI[entry.mood]}</span>
                      )}
                    </div>

                    {entry ? (
                      <button
                        onClick={() => { setFocusDay(ds); setLevel('day'); }}
                        className="text-sm text-stone-400 text-left line-clamp-2 hover:text-stone-600 transition-colors"
                      >
                        {entry.whatHappened || entry.feelings || entry.freeWrite || 'Entry saved.'}
                      </button>
                    ) : (
                      <button
                        onClick={() => onSelectDate(ds)}
                        className="text-sm text-stone-400 hover:text-stone-500 transition-colors"
                      >
                        {today ? "Write today's entry →" : 'Nothing written.'}
                      </button>
                    )}
                  </div>
                </motion.div>
              );
            })}
          </div>
        </motion.div>

        {/* Sentinel - reflection panel fades in as it enters viewport */}
        <div ref={sentinelRef} className="mt-6">
          <motion.div
            animate={{ opacity: reflectionVisible ? 1 : 0, y: reflectionVisible ? 0 : 12 }}
            transition={{ duration: 0.5 }}
          >
            <ReflectionPanel
              type="weekly"
              reflection={weeklyReflection}
              onWrite={() => onReflectionEntry(weeklyKey, 'weekly')}
              onEdit={() => onEditEntry(weeklyReflection!.date)}
            />
          </motion.div>
        </div>
      </div>
    );
  };

  // ── DAY VIEW - full entry read mode ───────────────────────────────────
  const DayView = () => {
    if (!focusDay) return null;
    const entry = entryMap.get(focusDay);

    if (!entry) {
      return (
        <div className="max-w-lg py-16">
          <p className="text-stone-400 text-sm mb-4">Nothing written for this day.</p>
          <Button onClick={() => onSelectDate(focusDay)} variant="outline" size="sm">
            Write an entry →
          </Button>
        </div>
      );
    }

    const moodStyle = entry.mood ? MOOD_BG[entry.mood] : 'bg-stone-50 border-stone-200';
    const moodText  = entry.mood ? MOOD_TEXT[entry.mood] : 'text-stone-500';

    const REFLECTION_BADGE: Record<string, { label: string; cls: string }> = {
      weekly:  { label: 'Weekly reflection', cls: 'bg-amber-100 text-amber-700' },
      monthly: { label: 'Monthly reflection', cls: 'bg-stone-200 text-stone-600' },
      yearly:  { label: 'Yearly reflection',  cls: 'bg-amber-100 text-amber-700' },
    };
    const badge = entry.reflectionType && entry.reflectionType !== 'daily'
      ? REFLECTION_BADGE[entry.reflectionType]
      : null;

    return (
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-2xl space-y-6"
      >
        {/* Date heading */}
        <div>
          <p
            className="text-3xl font-light leading-tight"
            style={{ fontFamily: 'var(--font-display)', color: '#3C3C38' }}
          >
            {format(parseISO(focusDay), 'EEEE, MMMM d')}
          </p>
          <p className="text-xs text-stone-400 mt-0.5 tracking-wide">
            {format(parseISO(focusDay), 'yyyy')}
          </p>
        </div>

        {badge && (
          <span className={`inline-block px-2.5 py-1 rounded-full text-xs font-medium tracking-wide ${badge.cls}`}>
            {badge.label}
          </span>
        )}

        {(entry.mood || entry.energy) && (
          <div className={`flex items-center gap-4 px-4 py-3 rounded-xl border ${moodStyle}`}>
            {entry.mood && (
              <span className={`text-sm font-medium flex items-center gap-2 ${moodText}`}>
                <span className="text-base">{MOOD_EMOJI[entry.mood]}</span>
                {MOOD_LABEL[entry.mood]}
              </span>
            )}
            {entry.energy && (
              <div className="flex items-end gap-0.5 ml-auto">
                {[1, 2, 3, 4, 5].map(l => (
                  <div
                    key={l}
                    className={`w-1.5 rounded-sm transition-all ${l <= entry.energy! ? 'bg-amber-400' : 'bg-stone-200'}`}
                    style={{ height: `${6 + l * 3}px` }}
                  />
                ))}
              </div>
            )}
          </div>
        )}

        {entry.innerState && (() => {
          const stateStyle: Record<string, string> = {
            clear:    'bg-stone-100 text-stone-600 border-stone-200',
            restless: 'bg-amber-50 text-amber-700 border-amber-100',
            heavy:    'bg-stone-100 text-stone-500 border-stone-200',
          };
          const stateLabel: Record<string, string> = {
            clear:    'Clear mind',
            restless: 'Restless mind',
            heavy:    'Heavy mind',
          };
          return (
            <span className={`inline-block px-2.5 py-1 rounded-full text-xs border ${stateStyle[entry.innerState!]}`}>
              {stateLabel[entry.innerState!]}
            </span>
          );
        })()}

        {entry.tags && entry.tags.length > 0 && (
          <div className="flex gap-2 flex-wrap">
            {entry.tags.map((tag: string) => (
              <button
                key={tag}
                onClick={() => {
                  setActiveTagFilter(activeTagFilter === tag ? null : tag);
                  setLevel('year');
                }}
                className={`px-2.5 py-1 text-xs rounded-full tracking-wide transition-all
                  ${activeTagFilter === tag
                    ? 'text-parchment'
                    : 'bg-stone-100 text-stone-500 hover:bg-stone-200 hover:text-stone-700'
                  }`}
                style={activeTagFilter === tag ? { backgroundColor: '#3C3C38', color: '#EDE8DF' } : undefined}
                title={activeTagFilter === tag ? 'Clear filter' : `Filter by "${tag}"`}
              >
                {tag}
              </button>
            ))}
          </div>
        )}

        {/* Content sections */}
        <div className="space-y-5">
          {[
            { key: 'whatHappened', label: 'What happened' },
            { key: 'feelings',     label: 'How it felt' },
            { key: 'whatMatters',  label: 'What mattered most' },
            { key: 'insight',      label: 'Insight' },
            { key: 'freeWrite',    label: 'Free write' },
          ].map(({ key, label }) => {
            const val = entry[key as keyof JournalEntry] as string;
            if (!val) return null;
            return (
              <div key={key}>
                <p className="text-[10px] text-stone-400 uppercase tracking-widest mb-2">{label}</p>
                <p className="leading-relaxed whitespace-pre-wrap text-[0.95rem]" style={{ color: '#3C3C38' }}>{val}</p>
              </div>
            );
          })}
        </div>

        <div className="pt-5 border-t border-stone-200/60">
          <Button
            variant="outline"
            size="sm"
            onClick={() => onEditEntry(focusDay)}
            className="gap-2"
          >
            <Edit className="size-3.5" />
            Edit this entry
          </Button>
        </div>
      </motion.div>
    );
  };

  // ── (Consolidated above) ──────────────────────────────────────────────

  return (
    <div className="h-screen w-full overflow-hidden flex flex-col font-sans" style={{ backgroundColor: '#F5F3EF', color: '#2E2A26' }}>
      <div className="flex-1 flex flex-col max-w-[1400px] mx-auto w-full px-6 pt-3 pb-2 min-h-0">
        <div className="flex flex-col items-center mb-[40px]">
          <h1 className="text-[36px] font-medium leading-none" style={{ color: '#2E2A26', fontFamily: '"Source Serif Pro", "Playfair Display", ui-serif, Georgia, serif', letterSpacing: '-0.02em' }}>
            Your Journal
          </h1>
          <div className="h-[6px]" />
          <p className="text-[14px] font-medium" style={{ color: '#6F6860' }}>A year of reflection</p>
          <div className="h-[16px]" />

          <div className="flex items-center gap-4">
            <button onClick={handlePrevYear} className="hover:text-[#2E2A26] transition-colors p-1" style={{ color: '#6F6860' }}>
              <ChevronLeft className="size-4" />
            </button>
            <span className="text-[18px] font-medium w-12 text-center" style={{ color: '#2E2A26', fontFamily: '"Source Serif Pro", serif', letterSpacing: '0.04em' }}>
              {year}
            </span>
            <button onClick={handleNextYear} className="hover:text-[#2E2A26] transition-colors p-1" style={{ color: '#6F6860' }}>
              <ChevronRight className="size-4" />
            </button>
          </div>
          <div className="h-[18px]" />

          <Button
            onClick={handleWriteToday}
            className="text-white rounded-xl h-[40px] px-6 flex items-center gap-2.5 transition-all shadow-none font-medium border-0 text-sm"
            style={{ backgroundColor: '#B8663F' }}
          >
            <Edit className="size-4" />
            <span>Write Today</span>
          </Button>

          <div className="mt-4 flex items-center gap-1.5 flex-wrap justify-center">
            <button
              onClick={() => setLevel('year')}
              className="hover:opacity-100 text-[11px] font-medium transition-colors uppercase tracking-widest"
              style={{ color: level === 'year' ? '#2E2A26' : '#6F6860' }}
            >
              {year}
            </button>
            
            {(level === 'month' || level === 'week' || level === 'day') && (
              <>
                <span className="text-[10px]" style={{ color: '#E2DBD2' }}>/</span>
                <button
                  onClick={() => setLevel('month')}
                  className={`text-[11px] font-medium transition-colors uppercase tracking-widest ${
                    level === 'month' ? 'cursor-default' : 'hover:opacity-100'
                  }`}
                  style={{ color: level === 'month' ? '#2E2A26' : '#6F6860' }}
                >
                  {MONTH_NAMES[focusMonth]}
                </button>
              </>
            )}

            {(level === 'week' || level === 'day') && (
              <>
                <span className="text-[#E2D9CD] text-[10px]">/</span>
                <button
                  onClick={() => setLevel('week')}
                  className={`text-[11px] font-medium transition-colors uppercase tracking-widest ${
                    level === 'week' ? 'text-[#2C2723] cursor-default' : 'text-[#A39A90] hover:text-[#2C2723]'
                  }`}
                >
                  {(() => {
                    const wStart = startOfMonth(new Date(year, focusMonth, 1));
                    const weeks  = eachWeekOfInterval({ start: wStart, end: endOfMonth(wStart) });
                    const idx    = weeks.findIndex(w => format(w, 'yyyy-MM-dd') === format(focusWeek, 'yyyy-MM-dd'));
                    return `Week ${idx >= 0 ? idx + 1 : 1}`;
                  })()}
                </button>
              </>
            )}

            {level === 'day' && focusDay && (
              <>
                <span className="text-[#E2D9CD] text-[10px]">/</span>
                <span className="text-[11px] font-medium text-[#2C2723] uppercase tracking-widest">
                  {format(parseISO(focusDay), 'EEE d')}
                </span>
              </>
            )}
          </div>
        </div>

        <AnimatePresence mode="wait">
          {level === 'year' && (
            <motion.div key="year" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="flex-1 flex flex-col min-h-0">
              <FilterStrip />
              <div className="flex-1 min-h-0 flex flex-col justify-center py-2">
                {showWelcome && (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="max-w-xl mx-auto mb-8 p-8 rounded-2xl text-center relative overflow-hidden"
                    style={{ 
                      backgroundColor: 'rgba(184, 102, 63, 0.05)',
                      border: '1px solid rgba(184, 102, 63, 0.15)'
                    }}
                  >
                    <button 
                      onClick={handleDismissWelcome}
                      className="absolute top-4 right-4 text-stone-400 hover:text-stone-600 transition-colors"
                      title="Dismiss"
                    >
                      <X className="size-4" />
                    </button>
                    <h2 className="text-2xl font-light mb-4" style={{ fontFamily: '"Source Serif Pro", serif', color: '#2E2A26' }}>
                      Welcome
                    </h2>
                    <p className="text-stone-600 leading-relaxed italic" style={{ fontFamily: 'ui-serif, Georgia, serif' }}>
                      "Write without concern for how it sounds or what it achieves. Just witness the mind."
                    </p>
                    <div className="mt-6 flex justify-center">
                      <div className="w-1.5 h-1.5 rounded-full bg-[#B8663F] opacity-40" />
                    </div>
                  </motion.div>
                )}
                <DailyHeatmap />
              </div>
              <div className="shrink-0 space-y-1 py-1">
                <LegendFooter />
                <BelowHeatmap />
              </div>
              {(() => {
                const yearlyReflection = findReflectionEntry(entries, 'yearly', String(year));
                if (!yearlyReflection) return null;
                return (
                  <div className="mt-2 max-w-xl mx-auto w-full">
                    <ReflectionPanel
                      type="yearly"
                      reflection={yearlyReflection}
                      onWrite={() => onReflectionEntry(`reflection-yearly-${year}`, 'yearly')}
                      onEdit={() => onEditEntry(yearlyReflection.date)}
                    />
                  </div>
                );
              })()}
            </motion.div>
          )}

          {level === 'month' && (
            <motion.div key="month" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="w-full max-w-2xl mx-auto overflow-y-auto">
              <MonthView />
            </motion.div>
          )}

          {level === 'week' && (
            <motion.div key="week" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="w-full max-w-2xl mx-auto overflow-y-auto">
              <WeekView />
            </motion.div>
          )}

          {level === 'day' && (
            <motion.div key="day" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="w-full max-w-2xl mx-auto overflow-y-auto">
              <DayView />
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
